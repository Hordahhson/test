# Hordahhson — Personal Site (Next.js + Tailwind)

A clean, SEO-ready personal site for a Pro 3D Artist & 3D Designer. Ready to deploy on Vercel.

## Quick Start

```bash
npm i
npm run dev
```

## Deploy

- Push to GitHub and **Import** in Vercel (recommended), or
- Use `vercel` CLI to deploy from your machine.

## Customize

- Update schema: `components/JsonLd.jsx` (`url`, `sameAs` links)
- Update metadata base/domain in `app/layout.js`
- Replace placeholder images in `app/portfolio/page.js`
- Add `/public/og.png` (1200x630) for social previews
- Change contact email in `app/contact/page.js`
- Replace sitemap/robots domain placeholders in `app/sitemap.js` and `app/robots.js`
```

