import Script from 'next/script';

export default function JsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": "Hordahhson",
    "alternateName": ["Hordahhson 3D"],
    "jobTitle": "Pro 3D Artist & 3D Designer",
    "url": "https://example.com", // TODO: replace with your custom domain or Vercel URL
    "image": "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=60",
    "sameAs": [
      "https://www.linkedin.com/",   // TODO: replace
      "https://www.instagram.com/",  // TODO: replace
      "https://twitter.com/",        // TODO: replace
      "https://www.artstation.com/"  // TODO: replace
    ],
    "knowsAbout": ["3D Modeling", "Texturing", "Rendering", "Visualization", "Animation"],
    "worksFor": {
      "@type": "Organization",
      "name": "Freelance"
    }
  };
  return (
    <Script id="jsonld-person" type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />
  );
}
