export default function Footer() {
  return (
    <footer className="border-t border-white/10 mt-16">
      <div className="container py-10 text-sm text-gray-300 flex flex-col md:flex-row items-center justify-between gap-4">
        <p>© {new Date().getFullYear()} Hordahhson — Pro 3D Artist & 3D Designer</p>
        <p className="text-gray-400">Built with Next.js · Tailwind</p>
      </div>
    </footer>
  );
}
