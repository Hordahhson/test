export const metadata = { title: 'About — Hordahhson' };

export default function About() {
  return (
    <article className="prose prose-invert max-w-none">
      <h1>About</h1>
      <p>
        I’m <strong>Hordahhson</strong>, a professional 3D artist and designer with deep experience in
        modeling, texturing, lighting, and rendering. I craft realistic assets and cinematic scenes for
        interactive experiences, animation, and brand visuals.
      </p>
      <h2>Expertise</h2>
      <ul>
        <li>Hard-surface & character modeling</li>
        <li>PBR texturing and lookdev</li>
        <li>Lighting, composition & rendering</li>
        <li>Environment design & visualization</li>
      </ul>
      <h2>Tools</h2>
      <p>Blender, Maya, ZBrush, Substance Painter, Unreal/Unity, KeyShot, Marvelous Designer.</p>
      <h2>Approach</h2>
      <p>
        My workflow balances artistry with technical precision: strong references, clean topology,
        efficient UVs, and materials tuned for real-time or offline pipelines.
      </p>
    </article>
  );
}
