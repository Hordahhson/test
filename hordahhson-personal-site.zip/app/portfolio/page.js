import Image from 'next/image';

export const metadata = { title: 'Portfolio — Hordahhson' };

const items = [
  {
    title: 'Hard-Surface Mech',
    img: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=60'
  },
  {
    title: 'Cinematic Character',
    img: 'https://images.unsplash.com/photo-1520975733028-0f4814b87368?auto=format&fit=crop&w=1200&q=60'
  },
  {
    title: 'Product Visualization',
    img: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=1200&q=60'
  },
  {
    title: 'Environment Study',
    img: 'https://images.unsplash.com/photo-1482192505345-5655af888cc4?auto=format&fit=crop&w=1200&q=60'
  }
];

export default function Portfolio() {
  return (
    <section>
      <h1 className="text-3xl font-semibold mb-6">Selected Works</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((it, i) => (
          <figure key={i} className="card p-0 overflow-hidden">
            <Image
              src={it.img}
              alt={it.title}
              width={1200}
              height={800}
              className="w-full h-56 object-cover"
            />
            <figcaption className="p-4 text-sm text-gray-300">{it.title}</figcaption>
          </figure>
        ))}
      </div>
      <p className="text-sm text-gray-400 mt-4">
        Replace these placeholders with your real renders. Tip: add 6–12 strong pieces.
      </p>
    </section>
  );
}
