export const metadata = { title: 'Contact — Hordahhson' };

export default function Contact() {
  return (
    <section className="grid md:grid-cols-2 gap-6">
      <div className="card">
        <h1 className="text-3xl font-semibold">Get in touch</h1>
        <p className="text-gray-300 mt-3">For commissions, collaborations, or freelance work:</p>
        <ul className="mt-4 text-gray-300">
          <li>Email: <a className="underline" href="mailto:hello@yourdomain.com">hello@yourdomain.com</a></li>
          <li>Instagram: <a className="underline" href="https://www.instagram.com/">@yourhandle</a></li>
          <li>ArtStation: <a className="underline" href="https://www.artstation.com/">artstation.com/yourname</a></li>
        </ul>
      </div>
      <div className="card">
        <h2 className="text-xl font-medium">Availability</h2>
        <p className="text-gray-300 mt-2">Open to freelance and long-term contracts. Timezone: Africa/Lagos.</p>
        <h3 className="mt-4 font-medium">Typical project types</h3>
        <ul className="list-disc ml-5 text-gray-300">
          <li>Game-ready assets & characters</li>
          <li>Product visualization & animation</li>
          <li>Environment & prop packs</li>
        </ul>
      </div>
    </section>
  );
}
