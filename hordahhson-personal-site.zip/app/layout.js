import './globals.css';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';
import JsonLd from '@/components/JsonLd';

export const metadata = {
  title: 'Hordahhson — Pro 3D Artist & Designer',
  description: 'Portfolio of Hordahhson, a professional 3D artist & designer.',
  metadataBase: new URL('https://example.com'),
  openGraph: {
    title: 'Hordahhson — Pro 3D Artist & Designer',
    description: 'Professional 3D artist & designer portfolio.',
    url: 'https://example.com',
    siteName: 'Hordahhson',
    images: ['/og.png'],
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hordahhson — Pro 3D Artist & Designer',
    description: 'Professional 3D artist & designer portfolio.',
    images: ['/og.png']
  }
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main className="container py-10">{children}</main>
        <Footer />
        <JsonLd />
      </body>
    </html>
  );
}
