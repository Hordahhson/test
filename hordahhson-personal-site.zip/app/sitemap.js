export default function sitemap() {
  const base = 'https://example.com'; // TODO: replace with your domain
  return [
    { url: `${base}/`, changefreq: 'weekly', priority: 1.0 },
    { url: `${base}/about`, changefreq: 'monthly', priority: 0.8 },
    { url: `${base}/portfolio`, changefreq: 'weekly', priority: 0.9 },
    { url: `${base}/contact`, changefreq: 'monthly', priority: 0.7 },
  ];
}
