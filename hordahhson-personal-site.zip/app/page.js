import Link from 'next/link';

export default function Home() {
  return (
    <section className="grid md:grid-cols-2 gap-8 items-center mt-8">
      <div className="card">
        <h1 className="text-4xl font-bold leading-tight">Hi, I’m <span className="text-brand-400">Hordahhson</span></h1>
        <p className="mt-4 text-lg text-gray-300">
          Pro 3D Artist & Experienced 3D Designer. I create cinematic models, textures,
          and high-fidelity renders for games, animation, and product visualization.
        </p>
        <div className="mt-6 flex gap-3">
          <Link href="/portfolio" className="px-5 py-3 rounded-xl bg-brand-600 hover:bg-brand-700">View Portfolio</Link>
          <Link href="/contact" className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20">Contact</Link>
        </div>
      </div>
      <div className="card">
        <div className="aspect-video w-full rounded-xl overflow-hidden bg-black/40 flex items-center justify-center">
          <p className="text-gray-400">Add your hero image/video here</p>
        </div>
        <p className="text-sm text-gray-400 mt-3">
          Tip: Replace this with a render or short reel cover to instantly show your style.
        </p>
      </div>
    </section>
  );
}
